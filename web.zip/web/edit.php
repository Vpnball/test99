<?php 
//ชื่อเว็บและรูปโลโก้
$nameweb = "NOOKER VPN THAILAND";
$imglogo = "icon.png";

//ลิ้งค์กลุ่ม
$nook = "https://ohhza.000webhostapp.com/CARTOON%E2%80%8B%20PRO.apk";
$adminline = "http://line.me/ti/p/Dh6o2a5Ar9";

//โปรดีเทค
$Dtac = "โปร ดีเทค";
$Dpro1text = "โกเพลิน";
$Dpro1call = "*103*55%23";
$Dpro2text = "ช็อปปิ้";
$Dpro2call = "*140*0999%23";

//โปรทรู
$True = "โปร ทรู";
$Tpro1text = "โซเชียล";
$Tpro1call = "*935*35%23";
$Tpro2text = "กันรั่ว";
$Tpro2call = "*900*8131%23";

//สคริปต์รันVPN
$scname = "สคิปรันวีพีเอ็น🖱";
$scexp = "หมดอายุ 30 ธันวาคม 2020";
$sclink = "wget -O install https://kguza.net/scrip/u-d/install.sh
bash install kguza-vpn";
//ใช้ลิงค์ ท้ายของยูทูป https://youtu.be/C3A-TPFgXTk
$scyt = "C3A-TPFgXTk";

//รายชื่อเข้าแอพ
$userapp = "ชื่อผู้ใช้รหัสผ่าน🖱";
$update = "อัพเดท รายชื่อ 16 พฤศจิกายน 2563";

$server[] = array("server" => "server1","user" => "thaicat","pass" => "thaicat");
$server[] = array("server" => "server2","user" => "thaiopl","pass" => "thaiopl");
$server[] = array("server" => "server3","user" => "thaizcom","pass" => "thaizcom");
$server[] = array("server" => "server3","user" => "thaizcom","pass" => "thaizcom");


//แอพทั้งหมด
$appname = "แอพพลิเคชั่นวีพีเอ็นฟรี";

$app[] = array(
"name" => "kguza-ssh v1 ",
"link" => "https://kguza.net/web/app/kguza-ssh-v1.apk"
);

$app[] = array(
"name" => "kguza-ssh v2 ",
"link" => "https://kguza.net/web/app/kguza-ssh.apk"
);

$app[] = array(
"name" => "ki4a ",
"link" => "https://kguza.net/web/app/ki4a_1.1.7_.apk"
);

$app[] = array(
"name" => "Es file ",
"link" => "https://kguza.net/web/app/ES_Pro.apk"
);

$app[] = array(
"name" => "hotspot",
"link" => "https://kguza.net/web/app/hotspot.apk"
);

?>